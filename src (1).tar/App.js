import {BrowserRouter, Route, Switch} from 'react-router-dom'

import Header from './components/Header'
import Home from './components/Home'
import About from './components/About'
import Contact from './components/Contact'
import Products from './components/Products'
import HomePage from './components/HomePage'
import NotFound from './components/NotFound'
import CartPage from './components/CartPage'

const App = () => (
  <BrowserRouter>
    <Header />
    <Switch>
      <Route exact path="/" component={Home} />
      <Route exact path="/about" component={About} />
      <Route exact path="/contact" component={Contact} />
      <Route exact path="/product" component={HomePage} />
      <Route exact path="/details/:id" component={Products} />
      <Route exact path="/cart" component={CartPage} />
      <Route component={NotFound} />
    </Switch>
  </BrowserRouter>
)

export default App
