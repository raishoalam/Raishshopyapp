import {Link} from 'react-router-dom'
import './index.css'

function HomePage() {
  return (
    <div className="home-section">
      <div className="card-wrapper">
        <div className="home-card">
          <h1 className="home-heading">Welcome to Our E-Commerce Store!</h1>
          <p className="home-description">
            Explore a world of convenience and choice with our curated selection
            of top-quality products. From the latest gadgets to fashion
            essentials, home decor, and beyond, we ve got everything you need to
            elevate your lifestyle. Shop confidently knowing that each item is
            handpicked for its quality and value, ensuring a seamless shopping
            experience every time. With exclusive deals, fast shipping, and
            stellar customer service, we re here to make your online shopping
            journey effortless and enjoyable. Join our community of savvy
            shoppers and start discovering your next favorite finds today!
          </p>
          <div className="home-button">
            <Link to="/product">
              <button className="home-btn" type="button">
                SHOP NOW
              </button>
            </Link>
          </div>
        </div>
        <div>
          <img
            src="https://img.freepik.com/free-photo/stylish-brunette-girl-red-jacket-against-studio-black-brick-wall_627829-9137.jpg?"
            alt="homeImg"
            className="home-img"
          />
        </div>
      </div>
    </div>
  )
}

export default HomePage
