// HomeDetailsPage.js
import './index.css'
import {useState, useEffect} from 'react'
import {useParams, Link, useHistory} from 'react-router-dom'

function HomeDetailsPage() {
  const {id} = useParams()
  const [product, setProduct] = useState(null)
  const history = useHistory()

  useEffect(() => {
    fetch(`https://dummyjson.com/products/${id}`)
      .then(response => response.json())
      .then(data => {
        setProduct(data)
      })
      .catch(error => console.error('Error fetching product details:', error))
  }, [id])

  const handleAddToCart = () => {
    // Add logic to add product to cart
    console.log('Product added to cart:', product)
    // Redirect to cart page
    history.push('/cart')
  }

  const handleDeleteItem = () => {
    // Add logic to delete the product
    console.log('Product deleted:', product)
  }

  return (
    <div className="product-details">
      <div className="details-wrapper">
        {product ? (
          <div className="product-details">
            <div className="detail-image">
              <img
                className="detail-img"
                src={product.thumbnail}
                alt={product.name}
              />
            </div>
            <div className="detail-content">
              <h1 className="detail-heading">{product.title}</h1>
              <p className="detail-desc">{product.description}</p>
              <p className="detail-price">Price: ${product.price}</p>
              <p className="rating">Rating: {product.rating}/5</p>
              <p className="brand">Brand: {product.brand}</p>
              <div className="detail-btn">
                <button
                  className="add-btn"
                  type="button"
                  onClick={handleAddToCart}
                >
                  Add to Cart
                </button>
                <button
                  className="remove-btn"
                  type="button"
                  onClick={handleDeleteItem}
                >
                  Delete Item
                </button>
              </div>
            </div>
          </div>
        ) : (
          <p>Loading...</p>
        )}
      </div>
    </div>
  )
}

export default HomeDetailsPage
