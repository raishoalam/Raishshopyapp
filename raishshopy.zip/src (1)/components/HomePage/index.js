import React, {useState, useEffect} from 'react'
import {Link} from 'react-router-dom'

import './index.css'

function HomePage() {
  const [products, setProducts] = useState([])

  useEffect(() => {
    fetch('https://dummyjson.com/products')
      .then(response => response.json())
      .then(data => {
        if (Array.isArray(data.products)) {
          setProducts(data.products)
        } else {
          console.error(
            'API response does not contain an array of products:',
            data,
          )
        }
      })
      .catch(error => console.error('Error fetching products:', error))
  }, [])

  return (
    <div className="product-section">
      <h1 className="product-main-heading">Welcome to our Store</h1>

      <div className="product-list">
        <div className="product-wrapper">
          {products.map(product => (
            <div key={product.id} className="product-card">
              <Link className="product-link" to={`/details/${product.id}`}>
                <div className="product-image">
                  <img
                    className="product-img"
                    src={product.thumbnail}
                    alt={product.name}
                  />
                </div>
                <h2 className="product-heading">{product.title}</h2>
                <p className="product-price">
                  Price: ${product.price}
                  <span className="disc">$1300</span>
                </p>
              </Link>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

export default HomePage
