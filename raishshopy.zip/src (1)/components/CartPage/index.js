// CartPage.js
import {useState} from 'react'
import {Link} from 'react-router-dom'

import './index.css'

function CartPage() {
  const [cartItems, setCartItems] = useState([])

  // Function to add an item to the cart
  const addToCart = product => setCartItems([...cartItems, product])

  // Function to remove an item from the cart
  const removeFromCart = productToRemove =>
    setCartItems(cartItems.filter(product => product !== productToRemove))

  // Calculate total amount
  const calculateTotal = () =>
    cartItems.reduce((total, product) => total + parseFloat(product.price), 0)

  return (
    <div className="cart-section">
      <h2 className="cart-heading">Add To Cart</h2>
      <div className="cart-img">
        <img
          src="https://img.freepik.com/free-vector/shopping-sprees-video-concept-illustration_335657-5383.jpg?"
          alt=""
          className="cart-image"
        />
      </div>
      {cartItems.length === 0 ? (
        <p>Your cart is empty</p>
      ) : (
        <div>
          {cartItems.map(item => (
            <div key={item.id}>
              {' '}
              {/* Assuming `item.id` is unique */}
              <p>
                {item.title} - ${item.price}
              </p>
              <button type="button" onClick={() => removeFromCart(item)}>
                Remove
              </button>
            </div>
          ))}
          <p>Total: ${calculateTotal().toFixed(2)}</p>
        </div>
      )}
      <Link className="back-btn" to="/">
        Back To Home
      </Link>
    </div>
  )
}

export default CartPage
